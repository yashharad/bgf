import React from 'react';
import Main from "./screens/Main";

export default function App() {
  return (
    <Main />
  )
}

